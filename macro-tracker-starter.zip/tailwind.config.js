/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        paper: "#faf7f2",
        ink: "#1c1b18",
        protein: "#5c6b2f",
        carb: "#c77c1e",
        fat: "#a4402a",
      },
    },
  },
  plugins: [],
};
