import { useState, useEffect } from "react";
import Calculator from "./components/Calculator.jsx";
import DailyLog from "./components/DailyLog.jsx";
import TrendChart from "./components/TrendChart.jsx";
import { getLogs, saveLog } from "./lib/storage.js";

export default function App() {
  const [tab, setTab] = useState("calculator");
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    setLogs(getLogs());
  }, []);

  function handleSave(results) {
    const updated = saveLog(results);
    setLogs(updated);
    setTab("log");
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <div className="max-w-4xl mx-auto px-5 py-8">
        <div className="text-[11px] tracking-widest uppercase text-stone-500 font-bold mb-1">
          Free & open starter
        </div>
        <h1 className="text-3xl font-extrabold mb-6">Macro Tracker</h1>

        <div className="flex gap-2 mb-8 border-b-[1.5px] border-stone-300">
          <TabButton active={tab === "calculator"} onClick={() => setTab("calculator")}>
            Calculator
          </TabButton>
          <TabButton active={tab === "log"} onClick={() => setTab("log")}>
            Daily Log
          </TabButton>
          <TabButton active={tab === "trends"} onClick={() => setTab("trends")}>
            Trends
          </TabButton>
        </div>

        {tab === "calculator" && <Calculator onSave={handleSave} />}
        {tab === "log" && <DailyLog logs={logs} />}
        {tab === "trends" && <TrendChart logs={logs} />}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 text-sm font-bold -mb-[1.5px] border-b-[3px] ${
        active ? "border-ink text-ink" : "border-transparent text-stone-400"
      }`}
    >
      {children}
    </button>
  );
}
