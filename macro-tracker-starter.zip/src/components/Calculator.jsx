import { useState } from "react";
import { ACTIVITY, GOALS, useMacros } from "../lib/useMacros.js";

export default function Calculator({ onSave }) {
  const [unit, setUnit] = useState("metric");
  const [sex, setSex] = useState("male");
  const [age, setAge] = useState(20);
  const [weight, setWeight] = useState(70);
  const [heightCm, setHeightCm] = useState(175);
  const [heightFt, setHeightFt] = useState(5);
  const [heightIn, setHeightIn] = useState(9);
  const [activity, setActivity] = useState("moderate");
  const [goal, setGoal] = useState("maintain");
  const [proteinPerKg, setProteinPerKg] = useState(1.8);
  const [fatPct, setFatPct] = useState(27);

  const results = useMacros({
    unit,
    sex,
    age,
    weight,
    heightCm,
    heightFt,
    heightIn,
    activity,
    goal,
    proteinPerKg,
    fatPct,
  });

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div className="space-y-5">
        <Seg label="Units" value={unit} onChange={setUnit} options={[
          { id: "metric", label: "kg / cm" },
          { id: "imperial", label: "lb / ft-in" },
        ]} />
        <Seg label="Sex" value={sex} onChange={setSex} options={[
          { id: "male", label: "Male" },
          { id: "female", label: "Female" },
        ]} />
        <div className="flex gap-4">
          <Num label="Age" value={age} onChange={setAge} min={14} max={90} suffix="yrs" />
          <Num
            label="Weight"
            value={weight}
            onChange={setWeight}
            min={30}
            max={unit === "metric" ? 250 : 550}
            suffix={unit === "metric" ? "kg" : "lb"}
          />
        </div>
        {unit === "metric" ? (
          <Num label="Height" value={heightCm} onChange={setHeightCm} min={120} max={230} suffix="cm" />
        ) : (
          <div className="flex gap-4">
            <Num label="Height (ft)" value={heightFt} onChange={setHeightFt} min={3} max={7} suffix="ft" />
            <Num label="Height (in)" value={heightIn} onChange={setHeightIn} min={0} max={11} suffix="in" />
          </div>
        )}
        <Seg label="Goal" value={goal} onChange={setGoal} options={GOALS.map((g) => ({ id: g.id, label: g.label }))} />
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">
            Activity level
          </div>
          <div className="space-y-1.5">
            {ACTIVITY.map((a) => (
              <button
                key={a.id}
                onClick={() => setActivity(a.id)}
                className={`w-full text-left px-3 py-2 border text-sm font-semibold ${
                  activity === a.id ? "border-ink bg-stone-100" : "border-stone-300"
                }`}
              >
                {a.label}
              </button>
            ))}
          </div>
        </div>
        <Slider
          label={`Protein target — ${proteinPerKg.toFixed(1)} g/kg`}
          value={proteinPerKg}
          onChange={setProteinPerKg}
          min={1.2}
          max={2.6}
          step={0.1}
          accent="#5c6b2f"
        />
        <Slider
          label={`Fat target — ${fatPct}% of calories`}
          value={fatPct}
          onChange={setFatPct}
          min={15}
          max={40}
          step={1}
          accent="#a4402a"
        />
      </div>

      <div>
        <div className="border-[3px] border-ink bg-white p-5">
          <div className="font-extrabold text-2xl border-b-[8px] border-ink pb-1.5 mb-1.5">
            Daily Targets
          </div>
          <div className="flex justify-between items-baseline border-b-[5px] border-ink pb-1 mb-1">
            <span className="font-extrabold">Calories</span>
            <span className="font-extrabold text-4xl">{results.targetCals}</span>
          </div>
          <Row label="Maintenance (TDEE)" value={`${results.tdee} cal`} />
          <Row label="Basal metabolic rate" value={`${results.bmr} cal`} bold />
          <MacroRow color="bg-protein" label="Protein" grams={results.proteinG} pct={results.proteinPct} />
          <MacroRow color="bg-carb" label="Carbohydrate" grams={results.carbG} pct={results.carbPct} />
          <MacroRow color="bg-fat" label="Fat" grams={results.fatG} pct={results.fatPct} last />
          <div className="flex h-3.5 mt-3 border border-ink">
            <div className="bg-protein" style={{ width: `${results.proteinPct}%` }} />
            <div className="bg-carb" style={{ width: `${results.carbPct}%` }} />
            <div className="bg-fat" style={{ width: `${results.fatPct}%` }} />
          </div>
        </div>
        <button
          onClick={() => onSave(results)}
          className="mt-4 w-full bg-ink text-white font-bold py-3 hover:opacity-90"
        >
          Save today's targets to my log
        </button>
      </div>
    </div>
  );
}

function Seg({ label, value, onChange, options }) {
  return (
    <div>
      <div className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">{label}</div>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o.id}
            onClick={() => onChange(o.id)}
            className={`px-3.5 py-2 text-sm font-semibold border-[1.5px] border-ink ${
              value === o.id ? "bg-ink text-white" : "bg-transparent text-ink"
            }`}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function Num({ label, value, onChange, min, max, suffix }) {
  return (
    <div className="flex-1">
      <div className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">{label}</div>
      <div className="flex items-center border-[1.5px] border-stone-300 px-2.5 py-1.5">
        <input
          type="number"
          value={value}
          min={min}
          max={max}
          onChange={(e) => {
            const v = parseFloat(e.target.value);
            if (!isNaN(v)) onChange(v);
          }}
          className="w-full outline-none font-bold text-base bg-transparent"
        />
        <span className="text-xs text-stone-500 font-semibold">{suffix}</span>
      </div>
    </div>
  );
}

function Slider({ label, value, onChange, min, max, step, accent }) {
  return (
    <div>
      <div className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-2">{label}</div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full"
        style={{ accentColor: accent }}
      />
    </div>
  );
}

function Row({ label, value, bold }) {
  return (
    <div
      className={`flex justify-between text-xs py-1 ${
        bold ? "border-b-2 border-ink mb-2 text-ink" : "border-b border-stone-200 text-stone-500"
      }`}
    >
      <span>{label}</span>
      <span className="font-bold text-ink">{value}</span>
    </div>
  );
}

function MacroRow({ color, label, grams, pct, last }) {
  return (
    <div className={`flex justify-between items-center py-1.5 ${last ? "" : "border-b border-stone-200"}`}>
      <div className="flex items-center gap-2">
        <div className={`w-2.5 h-2.5 ${color}`} />
        <span className="text-sm font-bold">{label}</span>
      </div>
      <div className="flex gap-2.5 items-baseline">
        <span className="text-xs text-stone-500">{pct}%</span>
        <span className="text-sm font-extrabold">{grams} g</span>
      </div>
    </div>
  );
}
