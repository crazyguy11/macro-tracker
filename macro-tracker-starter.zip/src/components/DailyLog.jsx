export default function DailyLog({ logs }) {
  if (logs.length === 0) {
    return (
      <div className="text-stone-500 text-sm">
        No entries yet. Save today's targets from the Calculator tab to start
        your log.
      </div>
    );
  }

  const sorted = [...logs].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div className="space-y-2">
      {sorted.map((log) => (
        <div
          key={log.date}
          className="border-[1.5px] border-stone-300 px-4 py-3 flex justify-between items-center"
        >
          <div>
            <div className="font-bold text-sm">{log.date}</div>
            <div className="text-xs text-stone-500">
              P {log.proteinG}g · C {log.carbG}g · F {log.fatG}g
            </div>
          </div>
          <div className="font-extrabold text-xl">{log.targetCals}</div>
        </div>
      ))}
    </div>
  );
}
