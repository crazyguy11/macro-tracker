import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function TrendChart({ logs }) {
  if (logs.length < 2) {
    return (
      <div className="text-stone-500 text-sm">
        Save at least two days of targets to see a trend line.
      </div>
    );
  }

  const data = [...logs].sort((a, b) => a.date.localeCompare(b.date));

  return (
    <div className="border-[1.5px] border-stone-300 p-4" style={{ height: 320 }}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid stroke="#e5e0d5" />
          <XAxis dataKey="date" tick={{ fontSize: 11 }} />
          <YAxis tick={{ fontSize: 11 }} />
          <Tooltip />
          <Line type="monotone" dataKey="targetCals" stroke="#1c1b18" strokeWidth={2} dot={{ r: 3 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
