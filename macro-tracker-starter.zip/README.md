# Macro Tracker — free starter project

A macro/calorie calculator + daily log, built with React, Vite, and Tailwind.
No backend required to start — everything saves to the browser. 100% free
tools throughout.

## 1. Run it locally

You need [Node.js](https://nodejs.org) installed (free, LTS version).

```bash
cd macro-tracker
npm install
npm run dev
```

Open the URL it prints (usually `http://localhost:5173`).

## 2. Put it on GitHub

```bash
git init
git add .
git commit -m "first commit"
```

Create a new empty repo on [github.com](https://github.com) (free), then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/macro-tracker.git
git branch -M main
git push -u origin main
```

## 3. Deploy for free

Go to [vercel.com](https://vercel.com), sign in with GitHub, click
**"Add New Project"**, pick your `macro-tracker` repo, and click Deploy.
Vercel auto-detects Vite — no config needed. You'll get a free URL like
`macro-tracker.vercel.app` in under a minute. Every push to `main` redeploys
automatically.

(Netlify works the same way if you prefer it.)

## 4. Make it installable as an app (PWA) — free, no app store

The `public/manifest.json` file is already set up. You just need two icon
files:

1. Make a 192×192 and a 512×512 PNG of your logo (even a simple text-on-color
   square works — you can generate one free at [favicon.io](https://favicon.io)).
2. Save them as `public/icon-192.png` and `public/icon-512.png`.

Once deployed, anyone visiting the site on Android/Chrome will get an
"Install app" prompt, and on iOS Safari can use "Add to Home Screen" — it
then opens full-screen like a native app, with no Play Store review needed.

## 5. Wrap it as a real Android/iOS app (when you're ready)

[Capacitor](https://capacitorjs.com) (free, open-source, by the Ionic team)
wraps your existing web app into a native project:

```bash
npm install @capacitor/core @capacitor/cli
npx cap init "Macro Tracker" "com.yourname.macrotracker"
npm run build
npx cap add android
npx cap add ios
npx cap open android   # opens Android Studio (free)
```

From Android Studio you can run it on an emulator or a real phone, and later
build a signed `.aab` to upload to the Play Store (Google's one-time
developer fee is $25 — the only non-free step in this whole pipeline; Apple's
developer program is $99/year for the App Store).

## 6. Phase 2 — accounts + cloud sync (Supabase, free tier)

Right now logs live only in the browser that saved them. To sync across
devices or support multiple users:

1. Create a free project at [supabase.com](https://supabase.com).
2. In the SQL editor, run:

```sql
create table logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users not null,
  date date not null,
  target_cals int not null,
  protein_g int not null,
  carb_g int not null,
  fat_g int not null,
  created_at timestamp default now(),
  unique (user_id, date)
);

alter table logs enable row level security;

create policy "Users manage their own logs"
  on logs for all
  using (auth.uid() = user_id);
```

3. Follow the comments in `src/lib/supabase.js` to wire it up — it already
   has the client setup and save/read functions ready to uncomment.
4. Add Supabase Auth (email magic link or Google login, both free) for
   account creation.

## Free AI tools worth using as you extend this

- **Claude.ai** — architecture decisions, full files, debugging.
- **GitHub Copilot** — free with the [Student Developer Pack](https://education.github.com/pack)
  if you're a student; in-editor autocomplete in VS Code.
- **v0.dev** / **bolt.new** — free tiers, good for quickly generating a UI
  component you then paste in and adapt.

## Project structure

```
macro-tracker/
  src/
    components/
      Calculator.jsx    — the macro calculator form + results
      DailyLog.jsx       — list of saved daily targets
      TrendChart.jsx      — calorie trend over time
    lib/
      useMacros.js       — the actual BMR/TDEE/macro math, shared
      storage.js          — localStorage read/write (swap for Supabase later)
      supabase.js          — commented-out cloud sync starter
    App.jsx               — tabs + layout
  public/
    manifest.json          — makes the site installable (PWA)
```
